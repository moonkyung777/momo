$(function(){
		$('#carousel1').infiniteCarousel();
	});